// ==UserScript==
// @name           000-xiaoxiaoflood.uc.js
// @description    alice0775 UC 环境运行 xiaoxiaoflood 脚本的依赖（不是所有脚本都能运行）
// @namespace      https://github.com/benzBrake/FirefoxCustomize/
// @author         Ryan
// @include        *
// @license        MIT License
// @compatibility  Firefox 68
// @charset        UTF-8
// @version        0.0.1
// @homepageURL    https://github.com/benzBrake/FirefoxCustomize/tree/master/userChromeJS
// ==/UserScript==
(function () {
    const Services = globalThis.Services || ChromeUtils.import("resource://gre/modules/Services.jsm").Services;
    const AppConstants = globalThis.AppConstants || ChromeUtils.import('resource://gre/modules/AppConstants.jsm').AppConstants;

    var initFakeUC = {
        observe: function (aSubject, aTopic, aData) {
            aSubject.addEventListener('load', this, true);
        },

        handleEvent: function (aEvent) {
            let document = aEvent.originalTarget;
            if (document.location && document.location.protocol == 'chrome:') {
                this.init(document.ownerGlobal);
            }
        },
        init(win) {
            if (!win.UC)
                win.UC = {
                    webExts: new Map(),
                    sidebar: new Map()
                }

            if (!win._uc) {
                win._uc = {
                    BROWSERCHROME: AppConstants.MOZ_APP_NAME == 'thunderbird' ? 'chrome://messenger/content/messenger.xhtml' : 'chrome://browser/content/browser.xhtml',
                    BROWSERTYPE: AppConstants.MOZ_APP_NAME == 'thunderbird' ? 'mail:3pane' : 'navigator:browser',
                    BROWSERNAME: AppConstants.MOZ_APP_NAME.charAt(0).toUpperCase() + AppConstants.MOZ_APP_NAME.slice(1),

                    chromedir: Services.dirsvc.get('UChrm', Ci.nsIFile),
                    sss: Cc["@mozilla.org/content/style-sheet-service;1"].getService(Ci.nsIStyleSheetService),

                    windows: function (fun, onlyBrowsers = true) {
                        let windows = Services.wm.getEnumerator(onlyBrowsers ? this.BROWSERTYPE : null);
                        while (windows.hasMoreElements()) {
                            let win = windows.getNext();
                            if (!win._uc)
                                continue;
                            if (!onlyBrowsers) {
                                let frames = win.docShell.getAllDocShellsInSubtree(Ci.nsIDocShellTreeItem.typeAll, Ci.nsIDocShell.ENUMERATE_FORWARDS);
                                let res = frames.some(frame => {
                                    let fWin = frame.domWindow;
                                    let { document, location } = fWin;
                                    if (fun(document, fWin, location))
                                        return true;
                                });
                                if (res)
                                    break;
                            } else {
                                let { document, location } = win;
                                if (fun(document, win, location))
                                    break;
                            }
                        }
                    },

                    createElement: function (doc, tag, atts, XUL = true) {
                        let el = XUL ? doc.createXULElement(tag) : doc.createElement(tag);
                        for (let att in atts) {
                            el.setAttribute(att, atts[att]);
                        }
                        return el
                    },

                    get isFaked() {
                        return true;
                    }
                }
            }
        }
    }

    initFakeUC.init(window);
})()